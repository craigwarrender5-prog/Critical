// CRITICAL: Master the Atom - Phase 1 Core Physics Engine
// CoupledThermo.cs - Coupled Pressure-Temperature-Volume Solver
//
// Implements: Gap #1 - P-T-V coupling (MOST CRITICAL)
//
// THE PROBLEM:
// In a closed RCS, temperature change causes expansion, but volume is constrained.
// This creates pressure increase, which changes density, which reduces expansion.
// Simple uncoupled model: 10°F rise → 0 psi change (WRONG!)
// Coupled model: 10°F rise → 60-80 psi change (CORRECT!)
//
// THE SOLUTION:
// Iterative solver that converges pressure, temperature, and volume
// to satisfy both state equations and conservation laws simultaneously.

using System;

namespace Critical.Physics
{
    /// <summary>
    /// Coupled thermodynamic solver for PWR RCS and pressurizer.
    /// This is the MOST CRITICAL module - all other phases depend on correct P-T-V coupling.
    /// 
    /// Key validation: 10°F Tavg rise must produce 60-80 psi pressure increase.
    /// If this test fails, the entire simulation will be unrealistic.
    /// </summary>
    public static class CoupledThermo
    {
        #region Constants
        
        /// <summary>Maximum iterations for solver convergence</summary>
        private const int MAX_ITERATIONS = 50;
        
        /// <summary>Pressure convergence tolerance in psi</summary>
        private const float PRESSURE_TOLERANCE = 0.1f;
        
        /// <summary>Volume convergence tolerance in ft³</summary>
        private const float VOLUME_TOLERANCE = 0.01f;
        
        /// <summary>Mass conservation tolerance as fraction</summary>
        private const float MASS_TOLERANCE = 0.001f;
        
        /// <summary>Relaxation factor for pressure updates (0-1, lower = more stable)</summary>
        private const float RELAXATION_FACTOR = 0.5f;
        
        #endregion
        
        #region Main Solver (Gap #1)
        
        /// <summary>
        /// Solve for equilibrium pressure after temperature change in closed RCS.
        /// This is the core coupled thermodynamic solver.
        /// 
        /// Physics: When T increases at constant total mass and volume:
        /// 1. Water wants to expand (ΔV = V × β × ΔT)
        /// 2. But total volume is fixed (RCS + PZR)
        /// 3. So pressure must increase to compress water back
        /// 4. Higher pressure changes density, which changes expansion
        /// 5. Iterate until consistent state is found
        /// </summary>
        /// <param name="state">System state (modified in place if converged)</param>
        /// <param name="deltaT_F">Temperature change in °F</param>
        /// <param name="maxIterations">Maximum solver iterations</param>
        /// <returns>True if converged, false otherwise</returns>
        public static bool SolveEquilibrium(ref SystemState state, float deltaT_F, int maxIterations = MAX_ITERATIONS)
        {
            // Save initial conditions for rollback if needed
            float P0 = state.Pressure;
            float T0 = state.Temperature;
            float M_total = state.RCSWaterMass + state.PZRWaterMass + state.PZRSteamMass;
            float V_total = state.RCSVolume + PlantConstants.PZR_TOTAL_VOLUME;
            
            // Target temperature
            float T_new = T0 + deltaT_F;
            
            // Initial pressure estimate using pressure coefficient
            float dPdT = ThermalExpansion.PressureCoefficient(T0, P0);
            float P_estimate = P0 + dPdT * deltaT_F * 0.5f; // Start conservative
            
            // Iteration variables
            float P_current = P0;
            float P_new = P_estimate;
            int iteration = 0;
            bool converged = false;
            
            while (iteration < maxIterations && !converged)
            {
                iteration++;
                
                // 1. Calculate new densities at (T_new, P_new)
                float rhoRCS = WaterProperties.WaterDensity(T_new, P_new);
                float tSat = WaterProperties.SaturationTemperature(P_new);
                float rhoPZRWater = WaterProperties.WaterDensity(tSat, P_new);
                float rhoPZRSteam = WaterProperties.SaturatedSteamDensity(P_new);
                
                // 2. Calculate RCS volume at new conditions (mass conserved)
                float V_RCS_new = state.RCSWaterMass / rhoRCS;
                
                // 3. Calculate volume change (expansion) trying to occur
                float deltaV_expansion = V_RCS_new - state.RCSVolume;
                
                // 4. This expansion must be accommodated by pressurizer
                // PZR steam space compresses, level rises
                float V_PZR_steam_new = state.PZRSteamVolume - deltaV_expansion;
                
                // 5. Check constraints
                // Minimum steam space
                V_PZR_steam_new = Math.Max(V_PZR_steam_new, PlantConstants.PZR_STEAM_MIN);
                
                // Maximum water volume
                float V_PZR_water_new = PlantConstants.PZR_TOTAL_VOLUME - V_PZR_steam_new;
                V_PZR_water_new = Math.Min(V_PZR_water_new, PlantConstants.PZR_WATER_MAX);
                
                // Recalculate steam volume after constraints
                V_PZR_steam_new = PlantConstants.PZR_TOTAL_VOLUME - V_PZR_water_new;
                
                // 6. Calculate masses at new conditions
                float M_PZR_water_new = V_PZR_water_new * rhoPZRWater;
                float M_PZR_steam_new = V_PZR_steam_new * rhoPZRSteam;
                
                // 7. Total mass check (mass must be conserved)
                float M_total_new = state.RCSWaterMass + M_PZR_water_new + M_PZR_steam_new;
                float massError = (M_total_new - M_total) / M_total;
                
                // 8. If mass not conserved, adjust pressure
                // Mass too high → pressure too high (steam too dense) → reduce P
                // Mass too low → pressure too low → increase P
                
                // Steam mass is most sensitive to pressure
                // Use steam compressibility to estimate pressure correction
                float steamCompressibility = 1f / P_new; // Ideal gas approximation
                float dP_mass = -massError / (steamCompressibility * V_PZR_steam_new / M_total);
                
                // 9. Volume constraint check
                float V_total_new = state.RCSVolume + PlantConstants.PZR_TOTAL_VOLUME;
                // Note: RCS volume is fixed (rigid piping), only PZR level changes
                
                // 10. Update pressure estimate with relaxation
                P_new = P_current + RELAXATION_FACTOR * (P_new - P_current + dP_mass);
                
                // Clamp pressure to physical limits
                P_new = Math.Max(P_new, 1000f);
                P_new = Math.Min(P_new, 3000f);
                
                // 11. Check convergence
                float pressureChange = Math.Abs(P_new - P_current);
                float massErrorAbs = Math.Abs(massError);
                
                if (pressureChange < PRESSURE_TOLERANCE && massErrorAbs < MASS_TOLERANCE)
                {
                    converged = true;
                }
                
                P_current = P_new;
            }
            
            // Update state if converged
            if (converged)
            {
                state.Temperature = T_new;
                state.Pressure = P_new;
                
                // Recalculate final volumes and masses
                float rhoRCS = WaterProperties.WaterDensity(T_new, P_new);
                float tSat = WaterProperties.SaturationTemperature(P_new);
                float rhoPZRWater = WaterProperties.WaterDensity(tSat, P_new);
                float rhoPZRSteam = WaterProperties.SaturatedSteamDensity(P_new);
                
                // RCS mass unchanged, volume adjusts slightly due to compressibility
                float V_RCS_final = state.RCSWaterMass / rhoRCS;
                float deltaV = V_RCS_final - state.RCSVolume;
                
                // PZR accommodates expansion
                state.PZRSteamVolume = Math.Max(state.PZRSteamVolume - deltaV, PlantConstants.PZR_STEAM_MIN);
                state.PZRWaterVolume = PlantConstants.PZR_TOTAL_VOLUME - state.PZRSteamVolume;
                
                state.PZRWaterMass = state.PZRWaterVolume * rhoPZRWater;
                state.PZRSteamMass = state.PZRSteamVolume * rhoPZRSteam;
                
                state.IterationsUsed = iteration;
            }
            else
            {
                // Rollback on failure
                state.Pressure = P0;
                state.Temperature = T0;
                state.IterationsUsed = iteration;
            }
            
            return converged;
        }
        
        /// <summary>
        /// Simplified coupled solver for quick estimates.
        /// Uses analytic approximation instead of full iteration.
        /// </summary>
        /// <param name="T0">Initial temperature in °F</param>
        /// <param name="P0">Initial pressure in psia</param>
        /// <param name="deltaT">Temperature change in °F</param>
        /// <param name="V_RCS">RCS volume in ft³</param>
        /// <param name="V_PZR_steam">Pressurizer steam volume in ft³</param>
        /// <returns>Pressure change in psi</returns>
        public static float QuickPressureEstimate(
            float T0, float P0, float deltaT, 
            float V_RCS, float V_PZR_steam)
        {
            // Simplified model:
            // ΔP = (β × ΔT × V_RCS) / (κ × V_RCS + C_steam × V_steam)
            // where C_steam is steam compressibility
            
            float beta = ThermalExpansion.ExpansionCoefficient(T0, P0);
            float kappa = ThermalExpansion.Compressibility(T0, P0);
            float steamComp = 1f / P0; // Ideal gas approximation
            
            // Effective compressibility includes steam cushion
            float effectiveComp = (kappa * V_RCS + steamComp * V_PZR_steam) / V_RCS;
            
            // Pressure rise
            float deltaP = (beta / effectiveComp) * deltaT;
            
            // Apply correction factor (empirical, accounts for non-ideal effects)
            deltaP *= 0.85f;
            
            return deltaP;
        }
        
        #endregion
        
        #region Transient Solver
        
        /// <summary>
        /// Solve coupled system over a time step with heat input.
        /// </summary>
        /// <param name="state">System state</param>
        /// <param name="heatInput_BTU_sec">Net heat input to RCS in BTU/sec</param>
        /// <param name="dt_sec">Time step in seconds</param>
        /// <returns>True if converged</returns>
        public static bool SolveTransient(ref SystemState state, float heatInput_BTU_sec, float dt_sec)
        {
            // Calculate temperature change from heat input
            // Q = m × Cp × ΔT
            float totalMass = state.RCSWaterMass + state.PZRWaterMass;
            float cp = WaterProperties.WaterSpecificHeat(state.Temperature, state.Pressure);
            
            // Include metal thermal mass
            float metalCapacity = PlantConstants.RCS_METAL_MASS * PlantConstants.STEEL_CP;
            float effectiveCapacity = totalMass * cp + metalCapacity;
            
            float deltaT = heatInput_BTU_sec * dt_sec / effectiveCapacity;
            
            // Solve for new equilibrium
            return SolveEquilibrium(ref state, deltaT);
        }
        
        /// <summary>
        /// Solve with pressurizer control systems active.
        /// </summary>
        /// <param name="state">System state</param>
        /// <param name="pzrState">Pressurizer state</param>
        /// <param name="heatInput_BTU_sec">Heat input to RCS</param>
        /// <param name="dt_sec">Time step</param>
        /// <returns>True if converged</returns>
        public static bool SolveWithPressurizer(
            ref SystemState state, 
            ref PressurizerState pzrState,
            float heatInput_BTU_sec,
            float dt_sec)
        {
            // 1. Calculate preliminary pressure from coupled thermodynamics
            float cp = WaterProperties.WaterSpecificHeat(state.Temperature, state.Pressure);
            float totalMass = state.RCSWaterMass + state.PZRWaterMass;
            float metalCapacity = PlantConstants.RCS_METAL_MASS * PlantConstants.STEEL_CP;
            float effectiveCapacity = totalMass * cp + metalCapacity;
            
            float deltaT = heatInput_BTU_sec * dt_sec / effectiveCapacity;
            
            // Quick estimate for pressure change without controls
            float deltaP_noControl = QuickPressureEstimate(
                state.Temperature, state.Pressure, deltaT,
                state.RCSVolume, pzrState.SteamVolume);
            
            // 2. Calculate pressurizer control responses
            float pressure_psig = state.Pressure - PlantConstants.PSIG_TO_PSIA;
            float heaterDemand = PressurizerPhysics.HeaterPowerDemand(pressure_psig);
            float sprayDemand = PressurizerPhysics.SprayFlowDemand(pressure_psig);
            
            // 3. Calculate surge flow from expansion
            float beta = ThermalExpansion.ExpansionCoefficient(state.Temperature, state.Pressure);
            float surgeVolume = state.RCSVolume * beta * deltaT;
            float surgeFlow_gpm = surgeVolume / PlantConstants.GPM_TO_FT3_SEC / dt_sec;
            
            // 4. Update pressurizer state
            PressurizerPhysics.ThreeRegionUpdate(
                ref pzrState,
                surgeFlow_gpm,
                PlantConstants.T_HOT,
                sprayDemand,
                PlantConstants.T_COLD,
                heaterDemand,
                dt_sec);
            
            // 5. Update pressure rate
            pzrState.PressureRate = deltaP_noControl / dt_sec;
            
            // 6. Calculate actual pressure change with controls
            // Heaters add steam → increase pressure
            // Spray condenses steam → decrease pressure
            // Flash evaporation → reduces pressure drop rate
            
            float steamGeneration = pzrState.HeaterSteamRate - pzrState.SprayCondRate - 
                                   pzrState.WallCondRate + pzrState.FlashRate;
            
            // Steam compressibility
            float rhog = WaterProperties.SaturatedSteamDensity(state.Pressure);
            float dP_steam = steamGeneration * dt_sec / (pzrState.SteamVolume * rhog) * state.Pressure;
            
            // Total pressure change
            float deltaP_actual = deltaP_noControl + dP_steam;
            
            // 7. Solve for final equilibrium
            state.Temperature += deltaT;
            state.Pressure += deltaP_actual;
            
            // Clamp pressure
            state.Pressure = Math.Max(state.Pressure, 1500f);
            state.Pressure = Math.Min(state.Pressure, 2600f);
            
            // Update pressurizer pressure
            pzrState.Pressure = state.Pressure;
            
            return true; // Simplified - always returns true for now
        }
        
        #endregion
        
        #region Validation Tests
        
        /// <summary>
        /// CRITICAL TEST: Verify 10°F rise produces 60-80 psi increase.
        /// This is THE key validation for Gap #1.
        /// If this fails, the entire simulation will be unrealistic.
        /// </summary>
        /// <returns>True if pressure response is in valid range</returns>
        public static bool Validate10DegreeTest()
        {
            // Initialize at normal operating conditions
            var state = InitializeAtSteadyState();
            float P0 = state.Pressure;
            
            // Apply 10°F temperature rise
            bool converged = SolveEquilibrium(ref state, 10f);
            
            if (!converged) return false;
            
            float deltaP = state.Pressure - P0;
            
            // Expected: 60-80 psi (6-8 psi/°F)
            // Accept slightly wider range for numerical tolerance: 50-100 psi
            return deltaP >= 50f && deltaP <= 100f;
        }
        
        /// <summary>
        /// Verify coupled expansion is less than uncoupled.
        /// </summary>
        public static bool ValidateCoupledLessThanUncoupled()
        {
            float T = 588f;
            float P = 2250f;
            float V = PlantConstants.RCS_WATER_VOLUME;
            float deltaT = 10f;
            
            // Uncoupled expansion (constant pressure)
            float uncoupled = ThermalExpansion.UncoupledSurgeVolume(V, deltaT, T, P);
            
            // Coupled expansion (pressure rises)
            float coupled = ThermalExpansion.CoupledSurgeVolume(V, PlantConstants.PZR_STEAM_VOLUME, deltaT, T, P);
            
            // Coupled should be less because pressure rise compresses water
            return coupled < uncoupled;
        }
        
        /// <summary>
        /// Verify mass is conserved through solver iterations.
        /// </summary>
        public static bool ValidateMassConservation()
        {
            var state = InitializeAtSteadyState();
            float initialMass = state.RCSWaterMass + state.PZRWaterMass + state.PZRSteamMass;
            
            // Apply temperature change
            SolveEquilibrium(ref state, 20f);
            
            float finalMass = state.RCSWaterMass + state.PZRWaterMass + state.PZRSteamMass;
            
            // Mass should be conserved within 0.1%
            float error = Math.Abs(finalMass - initialMass) / initialMass;
            return error < 0.001f;
        }
        
        /// <summary>
        /// Verify total volume is conserved (RCS is rigid).
        /// </summary>
        public static bool ValidateVolumeConservation()
        {
            var state = InitializeAtSteadyState();
            float initialVolume = state.RCSVolume + state.PZRWaterVolume + state.PZRSteamVolume;
            
            // Apply temperature change
            SolveEquilibrium(ref state, 15f);
            
            float finalVolume = state.RCSVolume + state.PZRWaterVolume + state.PZRSteamVolume;
            
            // Volume should be conserved within 0.01%
            float error = Math.Abs(finalVolume - initialVolume) / initialVolume;
            return error < 0.0001f;
        }
        
        /// <summary>
        /// Verify solver converges within reasonable iterations.
        /// </summary>
        public static bool ValidateConvergence()
        {
            var state = InitializeAtSteadyState();
            
            bool converged = SolveEquilibrium(ref state, 10f);
            
            return converged && state.IterationsUsed < 20;
        }
        
        /// <summary>
        /// Verify steam space is clamped at minimum.
        /// </summary>
        public static bool ValidateSteamSpaceMinimum()
        {
            var state = InitializeAtSteadyState();
            
            // Large temperature rise to push toward solid
            SolveEquilibrium(ref state, 50f);
            
            // Steam volume should not go below minimum
            return state.PZRSteamVolume >= PlantConstants.PZR_STEAM_MIN;
        }
        
        /// <summary>
        /// Run all validation tests.
        /// </summary>
        public static bool ValidateAll()
        {
            bool valid = true;
            
            if (!Validate10DegreeTest())
            {
                Console.WriteLine("FAILED: 10°F test - pressure response not in 60-80 psi range");
                valid = false;
            }
            
            if (!ValidateCoupledLessThanUncoupled())
            {
                Console.WriteLine("FAILED: Coupled expansion not less than uncoupled");
                valid = false;
            }
            
            if (!ValidateMassConservation())
            {
                Console.WriteLine("FAILED: Mass not conserved");
                valid = false;
            }
            
            if (!ValidateVolumeConservation())
            {
                Console.WriteLine("FAILED: Volume not conserved");
                valid = false;
            }
            
            if (!ValidateConvergence())
            {
                Console.WriteLine("FAILED: Solver did not converge in reasonable iterations");
                valid = false;
            }
            
            if (!ValidateSteamSpaceMinimum())
            {
                Console.WriteLine("FAILED: Steam space went below minimum");
                valid = false;
            }
            
            return valid;
        }
        
        #endregion
        
        #region Initialization
        
        /// <summary>
        /// Initialize system state at normal steady-state conditions.
        /// </summary>
        public static SystemState InitializeAtSteadyState()
        {
            var state = new SystemState();
            
            state.Pressure = PlantConstants.OPERATING_PRESSURE;
            state.Temperature = PlantConstants.T_AVG;
            
            // RCS
            state.RCSVolume = PlantConstants.RCS_WATER_VOLUME;
            float rhoRCS = WaterProperties.WaterDensity(state.Temperature, state.Pressure);
            state.RCSWaterMass = state.RCSVolume * rhoRCS;
            
            // Pressurizer at 60% level
            float tSat = WaterProperties.SaturationTemperature(state.Pressure);
            float rhoPZRWater = WaterProperties.WaterDensity(tSat, state.Pressure);
            float rhoPZRSteam = WaterProperties.SaturatedSteamDensity(state.Pressure);
            
            state.PZRWaterVolume = PlantConstants.PZR_WATER_VOLUME;
            state.PZRSteamVolume = PlantConstants.PZR_STEAM_VOLUME;
            state.PZRWaterMass = state.PZRWaterVolume * rhoPZRWater;
            state.PZRSteamMass = state.PZRSteamVolume * rhoPZRSteam;
            
            state.IterationsUsed = 0;
            
            return state;
        }
        
        #endregion
    }
    
    /// <summary>
    /// System state for coupled thermodynamic solver.
    /// </summary>
    public struct SystemState
    {
        // Primary state variables
        public float Pressure;          // psia
        public float Temperature;       // °F (RCS average)
        
        // RCS state
        public float RCSVolume;         // ft³ (fixed - rigid piping)
        public float RCSWaterMass;      // lb
        
        // Pressurizer state
        public float PZRWaterVolume;    // ft³
        public float PZRSteamVolume;    // ft³
        public float PZRWaterMass;      // lb
        public float PZRSteamMass;      // lb
        
        // Solver diagnostics
        public int IterationsUsed;
        
        // Derived properties
        public float TotalMass => RCSWaterMass + PZRWaterMass + PZRSteamMass;
        public float TotalVolume => RCSVolume + PZRWaterVolume + PZRSteamVolume;
        public float PZRLevel => PZRWaterVolume / PlantConstants.PZR_TOTAL_VOLUME * 100f;
    }
}
