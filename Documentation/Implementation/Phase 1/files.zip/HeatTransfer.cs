// CRITICAL: Master the Atom - Phase 1 Core Physics Engine
// HeatTransfer.cs - Heat Exchanger and Enthalpy Transport Calculations
//
// Implements: Gap #10 - Enthalpy transport (surge water deficit)
// Key equations: Q = U × A × LMTD, Q = ṁ × Δh
// Units: BTU for heat, BTU/hr for heat rate, BTU/lb for enthalpy

using System;

namespace Critical.Physics
{
    /// <summary>
    /// Heat transfer calculations for steam generators, surge line, and condensation.
    /// Critical for understanding energy balance in pressurizer.
    /// </summary>
    public static class HeatTransfer
    {
        #region Log Mean Temperature Difference (LMTD)
        
        /// <summary>
        /// Calculate Log Mean Temperature Difference for counterflow heat exchanger.
        /// LMTD = (ΔT1 - ΔT2) / ln(ΔT1/ΔT2)
        /// </summary>
        /// <param name="T_hot_in">Hot fluid inlet temperature in °F</param>
        /// <param name="T_hot_out">Hot fluid outlet temperature in °F</param>
        /// <param name="T_cold_in">Cold fluid inlet temperature in °F</param>
        /// <param name="T_cold_out">Cold fluid outlet temperature in °F</param>
        /// <returns>LMTD in °F</returns>
        public static float LMTD(float T_hot_in, float T_hot_out, float T_cold_in, float T_cold_out)
        {
            // For counterflow: ΔT1 = Th,in - Tc,out, ΔT2 = Th,out - Tc,in
            float deltaT1 = T_hot_in - T_cold_out;
            float deltaT2 = T_hot_out - T_cold_in;
            
            // Handle edge cases
            if (deltaT1 <= 0f || deltaT2 <= 0f) return 0f;
            
            // If temperature differences are nearly equal, use arithmetic mean
            if (Math.Abs(deltaT1 - deltaT2) < 0.1f)
            {
                return (deltaT1 + deltaT2) / 2f;
            }
            
            // Standard LMTD formula
            return (deltaT1 - deltaT2) / (float)Math.Log(deltaT1 / deltaT2);
        }
        
        /// <summary>
        /// Calculate LMTD for parallel flow heat exchanger.
        /// </summary>
        public static float LMTD_ParallelFlow(float T_hot_in, float T_hot_out, float T_cold_in, float T_cold_out)
        {
            // For parallel flow: ΔT1 = Th,in - Tc,in, ΔT2 = Th,out - Tc,out
            float deltaT1 = T_hot_in - T_cold_in;
            float deltaT2 = T_hot_out - T_cold_out;
            
            if (deltaT1 <= 0f || deltaT2 <= 0f) return 0f;
            
            if (Math.Abs(deltaT1 - deltaT2) < 0.1f)
            {
                return (deltaT1 + deltaT2) / 2f;
            }
            
            return (deltaT1 - deltaT2) / (float)Math.Log(deltaT1 / deltaT2);
        }
        
        #endregion
        
        #region Heat Transfer Calculations
        
        /// <summary>
        /// Calculate heat transfer rate using Q = U × A × LMTD.
        /// </summary>
        /// <param name="U">Overall heat transfer coefficient in BTU/(hr·ft²·°F)</param>
        /// <param name="A">Heat transfer area in ft²</param>
        /// <param name="lmtd">Log mean temperature difference in °F</param>
        /// <returns>Heat transfer rate in BTU/hr</returns>
        public static float HeatTransferRate(float U, float A, float lmtd)
        {
            return U * A * lmtd;
        }
        
        /// <summary>
        /// Calculate UA product from heat duty and LMTD.
        /// </summary>
        /// <param name="Q_BTU_hr">Heat transfer rate in BTU/hr</param>
        /// <param name="lmtd">Log mean temperature difference in °F</param>
        /// <returns>UA product in BTU/(hr·°F)</returns>
        public static float UACalculation(float Q_BTU_hr, float lmtd)
        {
            if (lmtd < 0.1f) return 0f;
            return Q_BTU_hr / lmtd;
        }
        
        /// <summary>
        /// Calculate heat transfer rate from enthalpy transport.
        /// Q = ṁ × (h_out - h_in)
        /// </summary>
        /// <param name="massFlow_lb_sec">Mass flow rate in lb/sec</param>
        /// <param name="h_in">Inlet enthalpy in BTU/lb</param>
        /// <param name="h_out">Outlet enthalpy in BTU/lb</param>
        /// <returns>Heat transfer rate in BTU/sec</returns>
        public static float EnthalpyTransport(float massFlow_lb_sec, float h_in, float h_out)
        {
            return massFlow_lb_sec * (h_out - h_in);
        }
        
        /// <summary>
        /// Calculate heat transfer rate from temperature change.
        /// Q = ṁ × Cp × ΔT
        /// </summary>
        /// <param name="massFlow_lb_sec">Mass flow rate in lb/sec</param>
        /// <param name="cp">Specific heat in BTU/(lb·°F)</param>
        /// <param name="deltaT">Temperature change in °F</param>
        /// <returns>Heat transfer rate in BTU/sec</returns>
        public static float HeatFromTempChange(float massFlow_lb_sec, float cp, float deltaT)
        {
            return massFlow_lb_sec * cp * deltaT;
        }
        
        #endregion
        
        #region Surge Line Enthalpy Transport (Gap #10)
        
        /// <summary>
        /// Calculate surge water enthalpy deficit relative to pressurizer saturation.
        /// This is CRITICAL for pressurizer heat balance.
        /// Surge water (619°F) is subcooled relative to PZR saturation (653°F at 2250 psia).
        /// </summary>
        /// <param name="surgeTemp_F">Surge water temperature (typically T_hot = 619°F)</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Enthalpy deficit in BTU/lb (positive = surge water needs heating)</returns>
        public static float SurgeEnthalpyDeficit(float surgeTemp_F, float pressure_psia)
        {
            // Delegate to WaterProperties for consistency
            return WaterProperties.SurgeEnthalpyDeficit(surgeTemp_F, pressure_psia);
        }
        
        /// <summary>
        /// Calculate heating load on pressurizer from insurging subcooled water.
        /// When subcooled water enters the pressurizer, it must be heated to saturation.
        /// </summary>
        /// <param name="surgeFlow_gpm">Insurge flow rate in gpm (positive = into PZR)</param>
        /// <param name="surgeTemp_F">Surge water temperature in °F</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Heating load in BTU/sec</returns>
        public static float SurgeHeatingLoad(float surgeFlow_gpm, float surgeTemp_F, float pressure_psia)
        {
            if (surgeFlow_gpm <= 0f) return 0f;
            
            // Convert gpm to lb/sec
            float rho = WaterProperties.WaterDensity(surgeTemp_F, pressure_psia);
            float massFlow = surgeFlow_gpm * PlantConstants.GPM_TO_FT3_SEC * rho;
            
            // Enthalpy deficit
            float deltaH = SurgeEnthalpyDeficit(surgeTemp_F, pressure_psia);
            
            return massFlow * deltaH;
        }
        
        /// <summary>
        /// Calculate cooling effect from outsurging saturated water.
        /// When saturated water leaves the pressurizer, it carries enthalpy away.
        /// </summary>
        /// <param name="surgeFlow_gpm">Outsurge flow rate in gpm (positive value)</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Cooling load in BTU/sec</returns>
        public static float SurgeCoolingLoad(float surgeFlow_gpm, float pressure_psia)
        {
            if (surgeFlow_gpm <= 0f) return 0f;
            
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float rho = WaterProperties.WaterDensity(tSat, pressure_psia);
            float massFlow = surgeFlow_gpm * PlantConstants.GPM_TO_FT3_SEC * rho;
            
            // Saturated water carries its full enthalpy out
            float hSat = WaterProperties.SaturatedLiquidEnthalpy(pressure_psia);
            
            // Reference to RCS enthalpy at Tavg
            float hRCS = WaterProperties.WaterEnthalpy(PlantConstants.T_AVG, pressure_psia);
            
            return massFlow * (hSat - hRCS);
        }
        
        #endregion
        
        #region Condensation Heat Transfer
        
        /// <summary>
        /// Calculate film condensation heat transfer coefficient.
        /// Nusselt correlation for vertical surfaces.
        /// </summary>
        /// <param name="pressure_psia">Steam pressure</param>
        /// <param name="wallTemp_F">Wall temperature in °F</param>
        /// <param name="height_ft">Vertical height in ft</param>
        /// <returns>Heat transfer coefficient in BTU/(hr·ft²·°F)</returns>
        public static float CondensingHTC(float pressure_psia, float wallTemp_F, float height_ft)
        {
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float deltaT = tSat - wallTemp_F;
            
            if (deltaT <= 0f) return 0f;
            if (height_ft < 0.1f) height_ft = 0.1f;
            
            // Nusselt correlation for laminar film condensation:
            // h = 0.943 × [ρf × (ρf-ρg) × g × hfg × kf³ / (μf × L × ΔT)]^0.25
            
            // Simplified correlation for PWR conditions:
            // h ≈ C × (hfg / (L × ΔT))^0.25 where C is calibrated
            
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            
            // Calibrated for PWR operating conditions
            // Typical values: 150-300 BTU/(hr·ft²·°F)
            float C = 50f; // Calibration constant
            float htc = C * (float)Math.Pow(hfg / (height_ft * deltaT), 0.25);
            
            // Clamp to reasonable range
            return Math.Max(50f, Math.Min(htc, 500f));
        }
        
        /// <summary>
        /// Calculate condensation rate from heat transfer.
        /// </summary>
        /// <param name="htc">Heat transfer coefficient in BTU/(hr·ft²·°F)</param>
        /// <param name="area_ft2">Condensing area in ft²</param>
        /// <param name="steamTemp_F">Steam temperature in °F</param>
        /// <param name="surfaceTemp_F">Condensing surface temperature in °F</param>
        /// <param name="pressure_psia">Pressure in psia</param>
        /// <returns>Condensation rate in lb/sec</returns>
        public static float CondensationRate(
            float htc, 
            float area_ft2, 
            float steamTemp_F, 
            float surfaceTemp_F,
            float pressure_psia)
        {
            float deltaT = steamTemp_F - surfaceTemp_F;
            if (deltaT <= 0f) return 0f;
            
            // Heat transfer rate (BTU/hr)
            float Q = htc * area_ft2 * deltaT;
            
            // Convert to condensation rate using latent heat
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            
            // Convert BTU/hr to lb/sec
            return Q / hfg / 3600f;
        }
        
        #endregion
        
        #region Steam Generator Heat Transfer
        
        /// <summary>
        /// Calculate steam generator heat transfer rate.
        /// Uses SG parameters from PlantConstants.
        /// </summary>
        /// <param name="T_primary_in">Primary inlet temperature (T_hot) in °F</param>
        /// <param name="T_primary_out">Primary outlet temperature (T_cold) in °F</param>
        /// <param name="T_secondary">Secondary (steam) temperature in °F</param>
        /// <param name="UA_BTU_hr_F">UA product in BTU/(hr·°F)</param>
        /// <returns>Heat transfer rate in BTU/hr</returns>
        public static float SGHeatTransfer(
            float T_primary_in, 
            float T_primary_out, 
            float T_secondary,
            float UA_BTU_hr_F)
        {
            // For SG, secondary side is approximately at constant temperature (boiling)
            // Use modified LMTD for condensing/evaporating fluid
            float lmtd = LMTD(T_primary_in, T_primary_out, T_secondary, T_secondary);
            
            return UA_BTU_hr_F * lmtd;
        }
        
        /// <summary>
        /// Calculate effective UA for steam generator at given conditions.
        /// </summary>
        /// <param name="powerFraction">Power as fraction of full power (0-1)</param>
        /// <returns>Effective UA in BTU/(hr·°F)</returns>
        public static float SGUA(float powerFraction)
        {
            // At 100% power with LMTD = 43°F and Q = 3411 MW
            // UA = Q / LMTD = 3411e6 BTU/hr / 43°F / 4 SGs ≈ 2e7 BTU/(hr·°F) per SG
            
            float UA_full = PlantConstants.THERMAL_POWER_BTU_HR / PlantConstants.LMTD_100_PERCENT / PlantConstants.SG_COUNT;
            
            // UA varies with flow - simplified correlation
            // At low flow, UA decreases due to lower velocities
            float flowFactor = (float)Math.Pow(powerFraction, 0.2); // Weak dependence
            
            return UA_full * flowFactor;
        }
        
        #endregion
        
        #region Spray Heat Transfer
        
        /// <summary>
        /// Calculate spray water heating rate in pressurizer.
        /// Spray enters at T_cold and must be heated toward saturation.
        /// </summary>
        /// <param name="sprayFlow_gpm">Spray flow rate in gpm</param>
        /// <param name="sprayTemp_F">Spray temperature (typically T_cold) in °F</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Heating load in BTU/sec</returns>
        public static float SprayHeatingLoad(float sprayFlow_gpm, float sprayTemp_F, float pressure_psia)
        {
            if (sprayFlow_gpm <= 0f) return 0f;
            
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float deltaT = tSat - sprayTemp_F;
            
            if (deltaT <= 0f) return 0f;
            
            // Convert gpm to lb/sec
            float rho = WaterProperties.WaterDensity(sprayTemp_F, pressure_psia);
            float massFlow = sprayFlow_gpm * PlantConstants.GPM_TO_FT3_SEC * rho;
            
            // Heat required to bring spray to saturation
            float cp = WaterProperties.WaterSpecificHeat(sprayTemp_F, pressure_psia);
            
            return massFlow * cp * deltaT;
        }
        
        /// <summary>
        /// Calculate effective condensation from spray.
        /// Spray removes energy from steam space by condensing steam.
        /// </summary>
        /// <param name="sprayFlow_gpm">Spray flow rate in gpm</param>
        /// <param name="sprayTemp_F">Spray temperature in °F</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <param name="efficiency">Spray effectiveness (0-1, typically 0.85)</param>
        /// <returns>Condensation rate in lb/sec</returns>
        public static float SprayCondensationRate(
            float sprayFlow_gpm, 
            float sprayTemp_F, 
            float pressure_psia,
            float efficiency)
        {
            if (sprayFlow_gpm <= 0f) return 0f;
            
            // Energy absorbed by spray
            float heatingLoad = SprayHeatingLoad(sprayFlow_gpm, sprayTemp_F, pressure_psia);
            
            // This energy comes from condensing steam
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            
            // Apply efficiency factor
            return heatingLoad * efficiency / hfg;
        }
        
        #endregion
        
        #region Validation
        
        /// <summary>
        /// Validate heat transfer calculations.
        /// </summary>
        public static bool ValidateCalculations()
        {
            bool valid = true;
            
            // Test 1: LMTD calculation
            // Equal ΔTs should give arithmetic mean
            float lmtd1 = LMTD(200f, 150f, 100f, 50f);
            if (Math.Abs(lmtd1 - 100f) > 1f) valid = false;
            
            // Test 2: Surge enthalpy deficit at operating conditions
            // At 619°F vs 653°F saturation: deficit should be 50-70 BTU/lb
            float deficit = SurgeEnthalpyDeficit(619f, 2250f);
            if (deficit < 40f || deficit > 80f) valid = false;
            
            // Test 3: Condensing HTC should be reasonable
            float htc = CondensingHTC(2250f, 620f, 10f);
            if (htc < 50f || htc > 500f) valid = false;
            
            // Test 4: Enthalpy transport calculation
            float Q = EnthalpyTransport(100f, 500f, 600f);
            if (Math.Abs(Q - 10000f) > 1f) valid = false;
            
            // Test 5: Spray condensation rate should be positive
            float condensRate = SprayCondensationRate(900f, 558f, 2250f, 0.85f);
            if (condensRate <= 0f) valid = false;
            
            return valid;
        }
        
        #endregion
    }
}
