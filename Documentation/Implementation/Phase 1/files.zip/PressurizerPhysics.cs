// CRITICAL: Master the Atom - Phase 1 Core Physics Engine
// PressurizerPhysics.cs - Pressurizer Thermal-Hydraulics
//
// Implements: Gaps #2-8
//   #2 - Flash evaporation during outsurge
//   #3 - Spray condensation dynamics (η = 85%)
//   #4 - Non-equilibrium three-region model
//   #6 - Wall condensation
//   #7 - Rainout (bulk condensation)
//   #8 - Heater thermal dynamics (τ = 20s)
//
// Units: BTU, lb, °F, psia, ft³, seconds

using System;

namespace Critical.Physics
{
    /// <summary>
    /// Pressurizer thermal-hydraulic calculations.
    /// Models three-region (subcooled, saturated, steam) behavior
    /// with flash evaporation, spray condensation, heaters, and wall effects.
    /// </summary>
    public static class PressurizerPhysics
    {
        #region Three-Region Model (Gap #4)
        
        /// <summary>
        /// Update pressurizer state using three-region non-equilibrium model.
        /// Regions: subcooled liquid, saturated interface, steam space
        /// </summary>
        /// <param name="state">Current pressurizer state (modified in place)</param>
        /// <param name="surgeFlow_gpm">Surge flow (positive = insurge)</param>
        /// <param name="surgeTemp_F">Surge water temperature</param>
        /// <param name="sprayFlow_gpm">Spray flow</param>
        /// <param name="sprayTemp_F">Spray temperature</param>
        /// <param name="heaterPower_kW">Heater electrical power demand</param>
        /// <param name="dt_sec">Time step in seconds</param>
        public static void ThreeRegionUpdate(
            ref PressurizerState state,
            float surgeFlow_gpm,
            float surgeTemp_F,
            float sprayFlow_gpm,
            float sprayTemp_F,
            float heaterPower_kW,
            float dt_sec)
        {
            // 1. Calculate phase change rates
            float flashRate = FlashEvaporationRate(state.Pressure, state.PressureRate, state.WaterMass);
            float heaterSteamRate = HeaterSteamRate(heaterPower_kW, state.HeaterEffectivePower, state.Pressure);
            float sprayCondRate = SprayCondensationRate(sprayFlow_gpm, sprayTemp_F, state.Pressure);
            float wallCondRate = WallCondensationRate(state.WallTemp, state.Pressure, state.WallArea);
            float rainoutRate = RainoutRate(state.SteamTemp, state.Pressure, state.SteamMass);
            
            // 2. Net steam generation rate
            float netSteamRate = flashRate + heaterSteamRate - sprayCondRate - wallCondRate - rainoutRate;
            
            // 3. Surge flow mass rate
            float surgeFlowRate = SurgeMassFlowRate(surgeFlow_gpm, surgeTemp_F, state.Pressure);
            
            // 4. Mass balances
            float dWaterMass = -netSteamRate + surgeFlowRate + sprayCondRate + wallCondRate + rainoutRate;
            float dSteamMass = netSteamRate - sprayCondRate - wallCondRate - rainoutRate;
            
            // Note: flash and heater contribute to steam, condensation removes from steam
            // Surge flow adds/removes water directly
            dWaterMass = surgeFlowRate - flashRate - heaterSteamRate + sprayCondRate + wallCondRate + rainoutRate;
            dSteamMass = flashRate + heaterSteamRate - sprayCondRate - wallCondRate - rainoutRate;
            
            // 5. Update masses
            state.WaterMass += dWaterMass * dt_sec;
            state.SteamMass += dSteamMass * dt_sec;
            
            // 6. Clamp masses to physical limits
            float minSteamMass = PlantConstants.PZR_STEAM_MIN * 
                                WaterProperties.SaturatedSteamDensity(state.Pressure);
            state.SteamMass = Math.Max(state.SteamMass, minSteamMass);
            
            // Maximum water (leave minimum steam space)
            float maxWaterMass = (PlantConstants.PZR_TOTAL_VOLUME - PlantConstants.PZR_STEAM_MIN) *
                                WaterProperties.WaterDensity(
                                    WaterProperties.SaturationTemperature(state.Pressure), 
                                    state.Pressure);
            state.WaterMass = Math.Min(state.WaterMass, maxWaterMass);
            state.WaterMass = Math.Max(state.WaterMass, 0f);
            
            // 7. Update volumes
            float tSat = WaterProperties.SaturationTemperature(state.Pressure);
            float rhoWater = WaterProperties.WaterDensity(tSat, state.Pressure);
            float rhoSteam = WaterProperties.SaturatedSteamDensity(state.Pressure);
            
            state.WaterVolume = state.WaterMass / rhoWater;
            state.SteamVolume = state.SteamMass / rhoSteam;
            
            // 8. Update heater effective power (Gap #8 - thermal lag)
            state.HeaterEffectivePower = HeaterLagResponse(
                state.HeaterEffectivePower, heaterPower_kW, PlantConstants.HEATER_TAU, dt_sec);
            
            // 9. Update wall temperature
            UpdateWallTemperature(ref state, dt_sec);
            
            // 10. Update steam temperature (may be superheated or subcooled)
            state.SteamTemp = tSat; // Simplified: assume saturated steam
            
            // 11. Update stored rates for next step
            state.FlashRate = flashRate;
            state.SprayCondRate = sprayCondRate;
            state.HeaterSteamRate = heaterSteamRate;
            state.WallCondRate = wallCondRate;
            state.RainoutRate = rainoutRate;
            state.NetSteamRate = netSteamRate;
        }
        
        #endregion
        
        #region Flash Evaporation (Gap #2)
        
        /// <summary>
        /// Calculate flash evaporation rate during depressurization.
        /// Flash occurs when pressure drops and liquid becomes superheated relative to new saturation.
        /// Self-regulating: flash rate increases with depressurization rate.
        /// </summary>
        /// <param name="pressure_psia">Current pressure</param>
        /// <param name="pressureRate_psi_sec">Pressure change rate (negative = depressurization)</param>
        /// <param name="waterMass_lb">Liquid water mass</param>
        /// <returns>Flash evaporation rate in lb/sec (positive = evaporation)</returns>
        public static float FlashEvaporationRate(
            float pressure_psia, 
            float pressureRate_psi_sec, 
            float waterMass_lb)
        {
            // Flash only occurs during depressurization (negative pressure rate)
            if (pressureRate_psi_sec >= 0f) return 0f;
            
            // Get thermodynamic properties
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            if (hfg < 10f) return 0f; // Near critical point
            
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float cp = WaterProperties.WaterSpecificHeat(tSat, pressure_psia);
            
            // Saturation temperature rate of change with pressure (dTsat/dP)
            // Clausius-Clapeyron: dT/dP = T × v_fg / h_fg
            // Simplified: dTsat/dP ≈ 0.03-0.05 °F/psi at PWR conditions
            float dTsatdP = 0.04f; // °F/psi (typical at 2250 psia)
            
            // Temperature change rate of saturation line
            float dTsatdt = dTsatdP * pressureRate_psi_sec; // This is negative during depressurization
            
            // Flash evaporation removes enough energy to keep water at saturation
            // Energy balance: m_flash × hfg = m_water × cp × |dTsat/dt|
            // m_flash = m_water × cp × |dTsat/dt| / hfg
            
            float flashRate = waterMass_lb * cp * Math.Abs(dTsatdt) / hfg;
            
            // Apply limiting factor (not all water at interface can flash instantly)
            float flashEfficiency = 0.8f;
            flashRate *= flashEfficiency;
            
            // Clamp to reasonable maximum (can't flash more than available water)
            float maxFlashRate = waterMass_lb * 0.01f; // Max 1% per second
            flashRate = Math.Min(flashRate, maxFlashRate);
            
            return Math.Max(flashRate, 0f);
        }
        
        /// <summary>
        /// Calculate if flash evaporation should occur based on superheat.
        /// </summary>
        /// <param name="waterTemp_F">Actual water temperature</param>
        /// <param name="pressure_psia">Current pressure</param>
        /// <returns>Superheat in °F (positive = superheated, will flash)</returns>
        public static float WaterSuperheat(float waterTemp_F, float pressure_psia)
        {
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            return waterTemp_F - tSat;
        }
        
        #endregion
        
        #region Spray Condensation (Gap #3)
        
        /// <summary>
        /// Calculate spray condensation rate.
        /// Spray water (cold) absorbs heat from steam, causing condensation.
        /// Efficiency is typically 85% (not all spray contacts steam effectively).
        /// </summary>
        /// <param name="sprayFlow_gpm">Spray flow rate in gpm</param>
        /// <param name="sprayTemp_F">Spray temperature (typically Tcold = 558°F)</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Condensation rate in lb/sec</returns>
        public static float SprayCondensationRate(
            float sprayFlow_gpm, 
            float sprayTemp_F, 
            float pressure_psia)
        {
            if (sprayFlow_gpm <= 0f) return 0f;
            
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float subcooling = tSat - sprayTemp_F;
            
            if (subcooling <= 0f) return 0f; // Spray not subcooled
            
            // Convert spray flow to mass flow rate
            float rhoSpray = WaterProperties.WaterDensity(sprayTemp_F, pressure_psia);
            float sprayMassFlow = sprayFlow_gpm * PlantConstants.GPM_TO_FT3_SEC * rhoSpray;
            
            // Heat absorbed by spray = m_spray × cp × (Tsat - Tspray)
            float cp = WaterProperties.WaterSpecificHeat(sprayTemp_F, pressure_psia);
            float heatAbsorbed = sprayMassFlow * cp * subcooling;
            
            // This heat comes from condensing steam
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            float condensationRate = heatAbsorbed / hfg;
            
            // Apply spray efficiency (Gap #3: 85%)
            condensationRate *= PlantConstants.SPRAY_EFFICIENCY;
            
            return Math.Max(condensationRate, 0f);
        }
        
        /// <summary>
        /// Calculate spray flow demand based on pressure error.
        /// </summary>
        /// <param name="pressure_psig">Current pressure in psig</param>
        /// <returns>Spray flow in gpm (0 to SPRAY_FLOW_MAX)</returns>
        public static float SprayFlowDemand(float pressure_psig)
        {
            if (pressure_psig <= PlantConstants.P_SPRAY_ON)
                return 0f;
            
            if (pressure_psig >= PlantConstants.P_SPRAY_FULL)
                return PlantConstants.SPRAY_FLOW_MAX;
            
            // Linear ramp between P_SPRAY_ON and P_SPRAY_FULL
            float fraction = (pressure_psig - PlantConstants.P_SPRAY_ON) / 
                            (PlantConstants.P_SPRAY_FULL - PlantConstants.P_SPRAY_ON);
            
            return fraction * PlantConstants.SPRAY_FLOW_MAX;
        }
        
        #endregion
        
        #region Heater Dynamics (Gap #8)
        
        /// <summary>
        /// Calculate heater steam generation rate.
        /// Heaters boil saturated water at the liquid surface.
        /// </summary>
        /// <param name="demandPower_kW">Requested heater power in kW</param>
        /// <param name="effectivePower_kW">Current effective power (after thermal lag)</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Steam generation rate in lb/sec</returns>
        public static float HeaterSteamRate(
            float demandPower_kW, 
            float effectivePower_kW, 
            float pressure_psia)
        {
            if (effectivePower_kW <= 0f) return 0f;
            
            // Convert kW to BTU/sec
            float power_BTU_sec = effectivePower_kW * PlantConstants.KW_TO_BTU_SEC;
            
            // Steam generation rate = Power / hfg
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            if (hfg < 10f) return 0f;
            
            return power_BTU_sec / hfg;
        }
        
        /// <summary>
        /// Calculate heater effective power with thermal lag.
        /// First-order lag with time constant τ = 20 seconds.
        /// </summary>
        /// <param name="currentPower_kW">Current effective power</param>
        /// <param name="demandPower_kW">Demanded power</param>
        /// <param name="tau_sec">Time constant in seconds</param>
        /// <param name="dt_sec">Time step in seconds</param>
        /// <returns>New effective power in kW</returns>
        public static float HeaterLagResponse(
            float currentPower_kW, 
            float demandPower_kW, 
            float tau_sec, 
            float dt_sec)
        {
            if (tau_sec < 0.1f) return demandPower_kW;
            
            // First-order lag: dP/dt = (P_demand - P) / τ
            float alpha = 1f - (float)Math.Exp(-dt_sec / tau_sec);
            return currentPower_kW + alpha * (demandPower_kW - currentPower_kW);
        }
        
        /// <summary>
        /// Calculate heater power demand based on pressure error.
        /// </summary>
        /// <param name="pressure_psig">Current pressure in psig</param>
        /// <returns>Heater power demand in kW (0 to HEATER_POWER_TOTAL)</returns>
        public static float HeaterPowerDemand(float pressure_psig)
        {
            if (pressure_psig >= PlantConstants.P_HEATERS_OFF)
                return 0f;
            
            if (pressure_psig <= PlantConstants.P_HEATERS_ON)
                return PlantConstants.HEATER_POWER_TOTAL;
            
            // Proportional control between setpoints
            float fraction = (PlantConstants.P_HEATERS_OFF - pressure_psig) / 
                            (PlantConstants.P_HEATERS_OFF - PlantConstants.P_HEATERS_ON);
            
            return fraction * PlantConstants.HEATER_POWER_TOTAL;
        }
        
        /// <summary>
        /// Validate heater thermal lag behavior.
        /// At t = τ, response should be 63.2% of step change.
        /// At t = 3τ, response should be 95% of step change.
        /// </summary>
        public static bool ValidateHeaterLag()
        {
            float tau = PlantConstants.HEATER_TAU;
            
            // Start at 0, demand 100%
            float power = 0f;
            float demand = 100f;
            
            // After τ seconds, should be at 63.2%
            power = HeaterLagResponse(0f, demand, tau, tau);
            float expected63 = demand * (1f - (float)Math.Exp(-1f)); // 63.2%
            
            if (Math.Abs(power - expected63) > 1f) return false;
            
            // After 3τ seconds, should be at 95%
            power = HeaterLagResponse(0f, demand, tau, 3f * tau);
            float expected95 = demand * (1f - (float)Math.Exp(-3f)); // 95%
            
            if (Math.Abs(power - expected95) > 1f) return false;
            
            return true;
        }
        
        #endregion
        
        #region Wall Condensation (Gap #6)
        
        /// <summary>
        /// Calculate wall condensation rate.
        /// Steam condenses on pressurizer walls when wall is cooler than saturation.
        /// </summary>
        /// <param name="wallTemp_F">Wall temperature in °F</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <param name="wallArea_ft2">Wall surface area exposed to steam</param>
        /// <returns>Condensation rate in lb/sec</returns>
        public static float WallCondensationRate(
            float wallTemp_F, 
            float pressure_psia, 
            float wallArea_ft2)
        {
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float deltaT = tSat - wallTemp_F;
            
            if (deltaT <= 0f) return 0f; // Wall not subcooled
            
            // Film condensation heat transfer
            float htc = HeatTransfer.CondensingHTC(pressure_psia, wallTemp_F, PlantConstants.PZR_HEIGHT);
            
            // Heat transfer rate (BTU/hr)
            float Q_BTU_hr = htc * wallArea_ft2 * deltaT;
            
            // Convert to condensation rate
            float hfg = WaterProperties.LatentHeat(pressure_psia);
            float condensationRate = Q_BTU_hr / hfg / 3600f; // Convert to lb/sec
            
            return Math.Max(condensationRate, 0f);
        }
        
        /// <summary>
        /// Update wall temperature based on heat transfer with steam and liquid.
        /// </summary>
        private static void UpdateWallTemperature(ref PressurizerState state, float dt_sec)
        {
            float tSat = WaterProperties.SaturationTemperature(state.Pressure);
            
            // Wall thermal mass
            float wallCapacity = ThermalMass.PressurizerWallHeatCapacity();
            
            // Heat transfer from steam to wall
            float htcSteam = 50f; // BTU/(hr·ft²·°F) - natural convection
            float steamArea = state.WallArea * (state.SteamVolume / PlantConstants.PZR_TOTAL_VOLUME);
            float qSteam = htcSteam * steamArea * (tSat - state.WallTemp) / 3600f; // BTU/sec
            
            // Heat transfer from liquid to wall
            float htcLiquid = 200f; // BTU/(hr·ft²·°F) - higher due to liquid
            float liquidArea = state.WallArea * (state.WaterVolume / PlantConstants.PZR_TOTAL_VOLUME);
            float qLiquid = htcLiquid * liquidArea * (tSat - state.WallTemp) / 3600f; // BTU/sec
            
            // Total heat to wall
            float qTotal = qSteam + qLiquid;
            
            // Temperature change
            float dT = qTotal * dt_sec / wallCapacity;
            state.WallTemp += dT;
            
            // Clamp wall temperature
            state.WallTemp = Math.Max(state.WallTemp, PlantConstants.T_COLD);
            state.WallTemp = Math.Min(state.WallTemp, tSat + 10f);
        }
        
        #endregion
        
        #region Rainout (Gap #7)
        
        /// <summary>
        /// Calculate rainout (bulk condensation) rate.
        /// Occurs when steam becomes subcooled and condenses in bulk.
        /// </summary>
        /// <param name="steamTemp_F">Steam temperature in °F</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <param name="steamMass_lb">Steam mass</param>
        /// <returns>Rainout rate in lb/sec</returns>
        public static float RainoutRate(float steamTemp_F, float pressure_psia, float steamMass_lb)
        {
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float subcooling = tSat - steamTemp_F;
            
            if (subcooling <= 0f) return 0f; // Steam not subcooled
            
            // Rainout occurs when steam cools below saturation
            // Rate proportional to subcooling and steam mass
            // Time constant for rainout is fast (order of seconds)
            
            float tau_rainout = 5f; // seconds
            float rainoutRate = steamMass_lb * subcooling / (100f * tau_rainout);
            
            // Clamp to available steam
            rainoutRate = Math.Min(rainoutRate, steamMass_lb * 0.1f); // Max 10% per second
            
            return Math.Max(rainoutRate, 0f);
        }
        
        #endregion
        
        #region Surge Flow
        
        /// <summary>
        /// Calculate surge mass flow rate from volumetric flow.
        /// </summary>
        /// <param name="surgeFlow_gpm">Surge flow in gpm (positive = insurge)</param>
        /// <param name="surgeTemp_F">Surge water temperature</param>
        /// <param name="pressure_psia">Pressurizer pressure</param>
        /// <returns>Mass flow rate in lb/sec (positive = into pressurizer)</returns>
        public static float SurgeMassFlowRate(float surgeFlow_gpm, float surgeTemp_F, float pressure_psia)
        {
            float rho = WaterProperties.WaterDensity(surgeTemp_F, pressure_psia);
            return surgeFlow_gpm * PlantConstants.GPM_TO_FT3_SEC * rho;
        }
        
        #endregion
        
        #region Mass and Energy Balance
        
        /// <summary>
        /// Check mass conservation in pressurizer.
        /// </summary>
        /// <param name="state">Pressurizer state</param>
        /// <param name="initialMass_lb">Initial total mass</param>
        /// <param name="netMassIn_lb">Net mass added (surge + spray - relief)</param>
        /// <returns>Mass error as fraction of initial mass</returns>
        public static float MassBalanceError(PressurizerState state, float initialMass_lb, float netMassIn_lb)
        {
            float currentMass = state.WaterMass + state.SteamMass;
            float expectedMass = initialMass_lb + netMassIn_lb;
            
            if (expectedMass < 1f) return 0f;
            
            return Math.Abs(currentMass - expectedMass) / expectedMass;
        }
        
        /// <summary>
        /// Calculate total pressurizer energy content.
        /// </summary>
        /// <param name="state">Pressurizer state</param>
        /// <returns>Total energy in BTU</returns>
        public static float TotalEnergy(PressurizerState state)
        {
            float tSat = WaterProperties.SaturationTemperature(state.Pressure);
            
            float hf = WaterProperties.SaturatedLiquidEnthalpy(state.Pressure);
            float hg = WaterProperties.SaturatedSteamEnthalpy(state.Pressure);
            
            float waterEnergy = state.WaterMass * hf;
            float steamEnergy = state.SteamMass * hg;
            
            // Wall energy (relative to reference)
            float wallEnergy = ThermalMass.PressurizerWallHeatCapacity() * (state.WallTemp - 32f);
            
            return waterEnergy + steamEnergy + wallEnergy;
        }
        
        #endregion
        
        #region Initialization
        
        /// <summary>
        /// Initialize pressurizer state at steady-state conditions.
        /// </summary>
        /// <param name="pressure_psia">Initial pressure</param>
        /// <param name="levelPercent">Initial level as percentage (0-100)</param>
        /// <returns>Initialized pressurizer state</returns>
        public static PressurizerState InitializeSteadyState(float pressure_psia, float levelPercent)
        {
            var state = new PressurizerState();
            
            state.Pressure = pressure_psia;
            state.PressureRate = 0f;
            
            float tSat = WaterProperties.SaturationTemperature(pressure_psia);
            float rhoWater = WaterProperties.WaterDensity(tSat, pressure_psia);
            float rhoSteam = WaterProperties.SaturatedSteamDensity(pressure_psia);
            
            float level = levelPercent / 100f;
            state.WaterVolume = PlantConstants.PZR_TOTAL_VOLUME * level;
            state.SteamVolume = PlantConstants.PZR_TOTAL_VOLUME * (1f - level);
            
            state.WaterMass = state.WaterVolume * rhoWater;
            state.SteamMass = state.SteamVolume * rhoSteam;
            
            state.WallTemp = tSat;
            state.SteamTemp = tSat;
            state.WallArea = PlantConstants.PZR_WALL_AREA;
            
            state.HeaterEffectivePower = 0f;
            
            // Initialize rates to zero
            state.FlashRate = 0f;
            state.SprayCondRate = 0f;
            state.HeaterSteamRate = 0f;
            state.WallCondRate = 0f;
            state.RainoutRate = 0f;
            state.NetSteamRate = 0f;
            
            return state;
        }
        
        #endregion
        
        #region Validation
        
        /// <summary>
        /// Validate pressurizer physics calculations.
        /// </summary>
        public static bool ValidateCalculations()
        {
            bool valid = true;
            
            // Test 1: Flash evaporation rate should be positive during depressurization
            float flashRate = FlashEvaporationRate(2250f, -10f, 50000f);
            if (flashRate <= 0f) valid = false;
            
            // Test 2: Flash evaporation should be zero during pressurization
            float flashRate2 = FlashEvaporationRate(2250f, 10f, 50000f);
            if (flashRate2 != 0f) valid = false;
            
            // Test 3: Spray condensation should be positive
            float sprayRate = SprayCondensationRate(900f, 558f, 2250f);
            if (sprayRate <= 0f) valid = false;
            
            // Test 4: Spray condensation should be in reasonable range (15-30 lb/sec at full flow)
            if (sprayRate < 5f || sprayRate > 50f) valid = false;
            
            // Test 5: Heater steam rate should be positive
            float heaterRate = HeaterSteamRate(1800f, 1800f, 2250f);
            if (heaterRate <= 0f) valid = false;
            
            // Test 6: Heater steam rate should be in reasonable range (3-6 lb/sec)
            if (heaterRate < 1f || heaterRate > 10f) valid = false;
            
            // Test 7: Heater lag validation
            if (!ValidateHeaterLag()) valid = false;
            
            // Test 8: Wall condensation should be positive when wall is cold
            float wallCondRate = WallCondensationRate(620f, 2250f, 600f);
            if (wallCondRate <= 0f) valid = false;
            
            // Test 9: Rainout should be positive when steam is subcooled
            float rainoutRate = RainoutRate(640f, 2250f, 1000f);
            if (rainoutRate <= 0f) valid = false;
            
            // Test 10: Flash should retard pressure drop (flash reduces |dP/dt|)
            // This is verified by checking flash rate increases with |dP/dt|
            float flashSlow = FlashEvaporationRate(2250f, -5f, 50000f);
            float flashFast = FlashEvaporationRate(2250f, -20f, 50000f);
            if (flashFast <= flashSlow) valid = false;
            
            return valid;
        }
        
        #endregion
    }
    
    /// <summary>
    /// Pressurizer state structure for three-region model.
    /// </summary>
    public struct PressurizerState
    {
        // Primary state variables
        public float Pressure;          // psia
        public float PressureRate;      // psi/sec
        public float WaterMass;         // lb
        public float SteamMass;         // lb
        public float WaterVolume;       // ft³
        public float SteamVolume;       // ft³
        
        // Temperatures
        public float WallTemp;          // °F
        public float SteamTemp;         // °F
        
        // Heater state
        public float HeaterEffectivePower; // kW (after thermal lag)
        
        // Geometry
        public float WallArea;          // ft²
        
        // Calculated rates (for diagnostics)
        public float FlashRate;         // lb/sec
        public float SprayCondRate;     // lb/sec
        public float HeaterSteamRate;   // lb/sec
        public float WallCondRate;      // lb/sec
        public float RainoutRate;       // lb/sec
        public float NetSteamRate;      // lb/sec
        
        // Derived properties
        public float Level => WaterVolume / PlantConstants.PZR_TOTAL_VOLUME * 100f;
        public float TotalMass => WaterMass + SteamMass;
    }
}
