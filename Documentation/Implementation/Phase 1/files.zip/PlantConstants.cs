// CRITICAL: Master the Atom - Phase 1 Core Physics Engine
// PlantConstants.cs - Westinghouse 4-Loop PWR Reference Values (3411 MWt)
// 
// Source: Westinghouse 4-Loop FSAR (South Texas, Vogtle, V.C. Summer)
// NO CALCULATIONS - Static reference values only
// All values validated against FSAR documentation

namespace Critical.Physics
{
    /// <summary>
    /// Static reference constants for Westinghouse 4-Loop PWR (3411 MWt).
    /// All values from Final Safety Analysis Report (FSAR).
    /// Units: °F for temperature, psia for pressure, ft³ for volume, lb for mass, BTU for energy
    /// </summary>
    public static class PlantConstants
    {
        #region Reactor Coolant System (RCS)
        
        /// <summary>Core thermal power in MWt</summary>
        public const float THERMAL_POWER_MWT = 3411f;
        
        /// <summary>Core thermal power in BTU/hr (3411 MWt × 3.412e6 BTU/MWh)</summary>
        public const float THERMAL_POWER_BTU_HR = 3411f * 3.412e6f;
        
        /// <summary>Total RCS water volume in ft³</summary>
        public const float RCS_WATER_VOLUME = 11500f;
        
        /// <summary>Total RCS metal mass in lb (vessel, piping, SG tubes)</summary>
        public const float RCS_METAL_MASS = 2200000f;
        
        /// <summary>Normal operating pressure in psia</summary>
        public const float OPERATING_PRESSURE = 2250f;
        
        /// <summary>Hot leg temperature in °F</summary>
        public const float T_HOT = 619f;
        
        /// <summary>Cold leg temperature in °F</summary>
        public const float T_COLD = 558f;
        
        /// <summary>Average coolant temperature in °F</summary>
        public const float T_AVG = 588.5f;
        
        /// <summary>Core temperature rise in °F</summary>
        public const float CORE_DELTA_T = 61f;
        
        /// <summary>Total RCS flow rate in gpm (4 loops)</summary>
        public const float RCS_FLOW_TOTAL = 390400f;
        
        /// <summary>Total RCS flow rate in lb/sec</summary>
        public const float RCS_FLOW_LBM_SEC = 38400f;
        
        #endregion
        
        #region Pressurizer
        
        /// <summary>Total pressurizer volume in ft³</summary>
        public const float PZR_TOTAL_VOLUME = 1800f;
        
        /// <summary>Normal water volume in ft³ (60% level)</summary>
        public const float PZR_WATER_VOLUME = 1080f;
        
        /// <summary>Normal steam volume in ft³ (40% level)</summary>
        public const float PZR_STEAM_VOLUME = 720f;
        
        /// <summary>Pressurizer height in ft</summary>
        public const float PZR_HEIGHT = 52.75f;
        
        /// <summary>Pressurizer wall mass in lb</summary>
        public const float PZR_WALL_MASS = 200000f;
        
        /// <summary>Pressurizer wall surface area in ft²</summary>
        public const float PZR_WALL_AREA = 600f;
        
        /// <summary>Total heater power in kW</summary>
        public const float HEATER_POWER_TOTAL = 1800f;
        
        /// <summary>Proportional heater power in kW</summary>
        public const float HEATER_POWER_PROP = 500f;
        
        /// <summary>Backup heater power in kW</summary>
        public const float HEATER_POWER_BACKUP = 1300f;
        
        /// <summary>Heater thermal time constant in seconds</summary>
        public const float HEATER_TAU = 20f;
        
        /// <summary>Maximum spray flow rate in gpm</summary>
        public const float SPRAY_FLOW_MAX = 900f;
        
        /// <summary>Spray water temperature in °F (= Tcold)</summary>
        public const float SPRAY_TEMP = 558f;
        
        /// <summary>Spray condensation efficiency (0.85 = 85%)</summary>
        public const float SPRAY_EFFICIENCY = 0.85f;
        
        /// <summary>Minimum steam space volume in ft³</summary>
        public const float PZR_STEAM_MIN = 50f;
        
        /// <summary>Maximum water volume in ft³</summary>
        public const float PZR_WATER_MAX = 1750f;
        
        #endregion
        
        #region Pressure Setpoints (psia)
        
        /// <summary>Normal operating pressure in psia</summary>
        public const float P_NORMAL = 2250f;
        
        /// <summary>Normal operating pressure in psig</summary>
        public const float P_NORMAL_PSIG = 2235f;
        
        /// <summary>Heaters full ON setpoint in psig</summary>
        public const float P_HEATERS_ON = 2210f;
        
        /// <summary>Heaters OFF setpoint in psig</summary>
        public const float P_HEATERS_OFF = 2235f;
        
        /// <summary>Spray ON setpoint in psig</summary>
        public const float P_SPRAY_ON = 2260f;
        
        /// <summary>Spray full flow setpoint in psig</summary>
        public const float P_SPRAY_FULL = 2280f;
        
        /// <summary>PORV opening setpoint in psig</summary>
        public const float P_PORV = 2335f;
        
        /// <summary>Safety valve opening setpoint in psig</summary>
        public const float P_SAFETY = 2485f;
        
        /// <summary>High pressure reactor trip setpoint in psig</summary>
        public const float P_TRIP_HIGH = 2385f;
        
        /// <summary>Low pressure reactor trip setpoint in psig</summary>
        public const float P_TRIP_LOW = 1885f;
        
        #endregion
        
        #region Reactor Coolant Pumps (RCPs)
        
        /// <summary>Number of RCPs</summary>
        public const int RCP_COUNT = 4;
        
        /// <summary>Flow per RCP in gpm</summary>
        public const float RCP_FLOW_EACH = 97600f;
        
        /// <summary>RCP speed in rpm</summary>
        public const float RCP_SPEED = 1189f;
        
        /// <summary>RCP coastdown time constant in seconds</summary>
        public const float RCP_COASTDOWN_TAU = 12f;
        
        /// <summary>Heat added by each RCP in MW</summary>
        public const float RCP_HEAT_MW = 21f;
        
        /// <summary>Low flow trip setpoint (fraction of normal)</summary>
        public const float LOW_FLOW_TRIP = 0.87f;
        
        #endregion
        
        #region Natural Circulation
        
        /// <summary>Minimum natural circulation flow in gpm</summary>
        public const float NAT_CIRC_FLOW_MIN = 12000f;
        
        /// <summary>Maximum natural circulation flow in gpm</summary>
        public const float NAT_CIRC_FLOW_MAX = 23000f;
        
        /// <summary>Natural circulation as fraction of normal flow (minimum)</summary>
        public const float NAT_CIRC_PERCENT_MIN = 0.03f;
        
        /// <summary>Natural circulation as fraction of normal flow (maximum)</summary>
        public const float NAT_CIRC_PERCENT_MAX = 0.06f;
        
        #endregion
        
        #region Chemical Volume Control System (CVCS)
        
        /// <summary>Normal letdown flow in gpm</summary>
        public const float LETDOWN_NORMAL = 75f;
        
        /// <summary>Normal charging flow in gpm</summary>
        public const float CHARGING_NORMAL = 87f;
        
        /// <summary>RCP seal injection flow in gpm</summary>
        public const float SEAL_INJECTION = 32f;
        
        /// <summary>Boron transport time in seconds (~10 min)</summary>
        public const float BORON_TRANSPORT_TIME = 600f;
        
        /// <summary>Boric acid concentration in ppm</summary>
        public const float BORIC_ACID_CONC = 7000f;
        
        /// <summary>Boron worth in pcm/ppm (negative = worth)</summary>
        public const float BORON_WORTH = -9f;
        
        #endregion
        
        #region Steam Generators (Model F)
        
        /// <summary>Number of steam generators</summary>
        public const int SG_COUNT = 4;
        
        /// <summary>Heat transfer area per SG in ft²</summary>
        public const float SG_AREA_EACH = 55000f;
        
        /// <summary>Number of tubes per SG</summary>
        public const int SG_TUBES_EACH = 5626;
        
        /// <summary>Steam flow per SG in lb/hr</summary>
        public const float SG_STEAM_FLOW_EACH = 3.8e6f;
        
        /// <summary>Total steam flow in lb/hr</summary>
        public const float SG_STEAM_FLOW_TOTAL = 15.2e6f;
        
        /// <summary>Steam pressure in psia</summary>
        public const float SG_STEAM_PRESSURE = 1000f;
        
        /// <summary>Steam temperature in °F</summary>
        public const float SG_STEAM_TEMP = 545f;
        
        /// <summary>Feedwater temperature in °F</summary>
        public const float SG_FW_TEMP = 440f;
        
        /// <summary>Log mean temperature difference at 100% power in °F</summary>
        public const float LMTD_100_PERCENT = 43f;
        
        #endregion
        
        #region Reactor Core
        
        /// <summary>Number of fuel assemblies</summary>
        public const int FUEL_ASSEMBLIES = 193;
        
        /// <summary>Number of fuel rods per assembly</summary>
        public const int RODS_PER_ASSEMBLY = 264;
        
        /// <summary>Total number of fuel rods</summary>
        public const int TOTAL_RODS = 50952;
        
        /// <summary>Active fuel height in ft</summary>
        public const float ACTIVE_HEIGHT = 12f;
        
        /// <summary>Average linear heat rate in kW/ft</summary>
        public const float AVG_LINEAR_HEAT = 5.44f;
        
        /// <summary>Peak linear heat rate in kW/ft</summary>
        public const float PEAK_LINEAR_HEAT = 13f;
        
        #endregion
        
        #region Reactivity Coefficients
        
        /// <summary>Doppler coefficient in pcm/√°R (negative for safety)</summary>
        public const float DOPPLER_COEFF = -2.5f;
        
        /// <summary>Moderator temperature coefficient at high boron in pcm/°F</summary>
        public const float MTC_HIGH_BORON = 5f;
        
        /// <summary>Moderator temperature coefficient at low boron in pcm/°F</summary>
        public const float MTC_LOW_BORON = -40f;
        
        /// <summary>Boron concentration for MTC transition in ppm</summary>
        public const float MTC_TRANSITION_BORON = 500f;
        
        /// <summary>Total delayed neutron fraction (beta)</summary>
        public const float BETA_DELAYED = 0.0065f;
        
        /// <summary>Prompt neutron generation time in seconds</summary>
        public const float LAMBDA_PROMPT = 2e-5f;
        
        #endregion
        
        #region Control Rods
        
        /// <summary>Number of control rod banks</summary>
        public const int ROD_BANKS = 8;
        
        /// <summary>Rod withdrawal/insertion speed in steps/min</summary>
        public const float ROD_STEPS_PER_MINUTE = 72f;
        
        /// <summary>Total steps per rod</summary>
        public const int ROD_TOTAL_STEPS = 228;
        
        /// <summary>Minimum shutdown margin in pcm</summary>
        public const float SHUTDOWN_MARGIN = 8000f;
        
        #endregion
        
        #region Xenon Dynamics
        
        /// <summary>Equilibrium xenon worth at 100% power in pcm</summary>
        public const float XENON_EQUILIBRIUM_MIN = 2500f;
        
        /// <summary>Equilibrium xenon worth at 100% power in pcm (upper range)</summary>
        public const float XENON_EQUILIBRIUM_MAX = 3000f;
        
        /// <summary>Peak xenon worth after trip in pcm</summary>
        public const float XENON_PEAK_MIN = 3000f;
        
        /// <summary>Peak xenon worth after trip in pcm (upper range)</summary>
        public const float XENON_PEAK_MAX = 4000f;
        
        /// <summary>Time to peak xenon after trip in hours</summary>
        public const float XENON_PEAK_TIME_HOURS = 9f;
        
        /// <summary>Xenon-135 decay constant in 1/hr</summary>
        public const float XENON_DECAY_CONSTANT = 0.0753f;
        
        /// <summary>Iodine-135 decay constant in 1/hr</summary>
        public const float IODINE_DECAY_CONSTANT = 0.1035f;
        
        #endregion
        
        #region Decay Heat (ANS 5.1-2005)
        
        /// <summary>Decay heat at trip as fraction of full power</summary>
        public const float DECAY_HEAT_TRIP = 0.07f;
        
        /// <summary>Decay heat at 1 minute as fraction of full power</summary>
        public const float DECAY_HEAT_1MIN = 0.05f;
        
        /// <summary>Decay heat at 10 minutes as fraction of full power</summary>
        public const float DECAY_HEAT_10MIN = 0.03f;
        
        /// <summary>Decay heat at 1 hour as fraction of full power</summary>
        public const float DECAY_HEAT_1HR = 0.015f;
        
        /// <summary>Decay heat at 1 day as fraction of full power</summary>
        public const float DECAY_HEAT_1DAY = 0.005f;
        
        #endregion
        
        #region Turbine Generator
        
        /// <summary>Turbine electrical output in MW</summary>
        public const float TURBINE_OUTPUT_MW = 1150f;
        
        /// <summary>Turbine speed in rpm</summary>
        public const float TURBINE_SPEED = 1800f;
        
        /// <summary>Thermal efficiency (electrical/thermal)</summary>
        public const float TURBINE_EFFICIENCY = 0.34f;
        
        /// <summary>Governor droop (5% = 0.05)</summary>
        public const float GOVERNOR_DROOP = 0.05f;
        
        #endregion
        
        #region Physical Constants
        
        /// <summary>Steel specific heat in BTU/(lb·°F)</summary>
        public const float STEEL_CP = 0.12f;
        
        /// <summary>Water reference specific heat in BTU/(lb·°F)</summary>
        public const float WATER_CP_REF = 1.0f;
        
        /// <summary>Gravitational constant in ft/s²</summary>
        public const float GRAVITY = 32.174f;
        
        /// <summary>Atmospheric pressure in psia</summary>
        public const float P_ATM = 14.7f;
        
        /// <summary>Conversion: psig to psia</summary>
        public const float PSIG_TO_PSIA = 14.7f;
        
        #endregion
        
        #region Unit Conversions
        
        /// <summary>Conversion: gpm to ft³/sec</summary>
        public const float GPM_TO_FT3_SEC = 1f / 448.831f;
        
        /// <summary>Conversion: gpm to lb/sec (at ~46 lb/ft³)</summary>
        public const float GPM_TO_LBM_SEC = 46f / 448.831f;
        
        /// <summary>Conversion: kW to BTU/sec</summary>
        public const float KW_TO_BTU_SEC = 0.9478f;
        
        /// <summary>Conversion: MW to BTU/hr</summary>
        public const float MW_TO_BTU_HR = 3.412e6f;
        
        /// <summary>Conversion: Rankine offset (°R = °F + 459.67)</summary>
        public const float RANKINE_OFFSET = 459.67f;
        
        #endregion
        
        #region Surge Line
        
        /// <summary>Surge line diameter in inches</summary>
        public const float SURGE_LINE_DIAMETER = 14f;
        
        /// <summary>Surge line length in ft</summary>
        public const float SURGE_LINE_LENGTH = 50f;
        
        /// <summary>Surge line friction factor (Darcy)</summary>
        public const float SURGE_LINE_FRICTION = 0.015f;
        
        #endregion
        
        #region Validation Methods
        
        /// <summary>
        /// Verify that derived constants are consistent with base values.
        /// Returns true if all validation checks pass.
        /// </summary>
        public static bool ValidateConstants()
        {
            bool valid = true;
            
            // Check T_AVG calculation
            float calcTAvg = (T_HOT + T_COLD) / 2f;
            if (System.Math.Abs(calcTAvg - T_AVG) > 0.5f)
                valid = false;
            
            // Check CORE_DELTA_T
            float calcDeltaT = T_HOT - T_COLD;
            if (System.Math.Abs(calcDeltaT - CORE_DELTA_T) > 0.5f)
                valid = false;
            
            // Check RCS_FLOW_TOTAL
            float calcFlow = RCP_COUNT * RCP_FLOW_EACH;
            if (System.Math.Abs(calcFlow - RCS_FLOW_TOTAL) > 100f)
                valid = false;
            
            // Check PZR volumes
            float calcPzrWater = PZR_TOTAL_VOLUME * 0.6f;
            if (System.Math.Abs(calcPzrWater - PZR_WATER_VOLUME) > 1f)
                valid = false;
            
            // Check TOTAL_RODS
            int calcRods = FUEL_ASSEMBLIES * RODS_PER_ASSEMBLY;
            if (calcRods != TOTAL_RODS)
                valid = false;
            
            return valid;
        }
        
        /// <summary>
        /// Convert psig to psia
        /// </summary>
        public static float PsigToPsia(float psig)
        {
            return psig + PSIG_TO_PSIA;
        }
        
        /// <summary>
        /// Convert psia to psig
        /// </summary>
        public static float PsiaToPsig(float psia)
        {
            return psia - PSIG_TO_PSIA;
        }
        
        /// <summary>
        /// Convert °F to °R (Rankine)
        /// </summary>
        public static float FahrenheitToRankine(float fahrenheit)
        {
            return fahrenheit + RANKINE_OFFSET;
        }
        
        #endregion
    }
}
